// Zheen H. Suseyi
// 09/27/24
// Checkpoint 8




/*
 Your challenge is this: make a protocol that describes a building, adding various properties and methods, then create two structs, House and Office, that conform to it. Your protocol should require the following:

 A property storing how many rooms it has.
 A property storing the cost as an integer (e.g. 500,000 for a building costing $500,000.)
 A property storing the name of the estate agent responsible for selling the building.
 A method for printing the sales summary of the building, describing what it is along with its other properties.
 */
import UIKit

// Building protocol in which both House and Office have to conform to
protocol Building {
    // Initizing our varibles that will be both read and changed
    var rooms: Int {get set}
    var cost: Int {get set}
    var agent: String {get set}
    // a function for the sales sum that shall be used in both House and Office
    func saleSum()
}

// House struct that conforms to Building
struct House: Building{
    var rooms: Int
    var cost: Int
    var agent: String
    func saleSum(){
        print("This place has \(rooms) rooms woah")
        print("This place cost $\(cost) dollars!")
        print("And this was sold by real estate agent \(agent) wow!")
    }
}

// Office struct that conforms to building
struct Office: Building{
    var rooms: Int
    var cost: Int
    var agent: String
    func saleSum(){
        print("This place has \(rooms) rooms woah")
        print("This place cost $\(cost) dollars!")
        print("And this was sold by real estate agent \(agent) wow!")
    }
}

// Making new house and office objects and testing the result with saleSum()
let house = House(rooms: 8, cost: 1231231 , agent: "Bobby Perkins")
house.saleSum()


let office = Office(rooms: 80, cost: 12311231 , agent: "Bobby Johnson")
office.saleSum()
